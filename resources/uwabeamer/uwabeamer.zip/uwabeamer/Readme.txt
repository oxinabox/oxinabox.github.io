Prepared in 2015 
By Lyndon White


Instructions
-------------

to install copy the files 
	 - beamerbackgrounduwa.png
	 - beamercolorthemeuwa.sty
	 - beamerinnerthemeuwa.sty
	 - beamerouterthemeuwa.sty
	 - beamerthemeuwa.sty
Into your TeX path.
Putting them in the same directory as the project will do it.

See the example.tex for illustration of how to use.



Options:
-------
Takes an option `crossbullets`, if pressent uses "more interesting" cross/club shaped bullet points.
This requires the bbding package to have the icons.




License:
---------

This work contains content base on
 beameroutherthemesidebar.sty
 which is distributed with beamer.
 
 That work is Copyright 2007 by Till Tantau
 
 This work may be may be distributed and/or modified

 under the LaTeX Project Public License (include here as  LPPLicense.txt)

See the file doc\latex\beamer\licenses for more details.