Opinosis Opinion Dataset  1.0  - Documentation
============================================

Last revised: 
Tuesday, July 20, 2010
Author: Kavita Ganesan (kganes2@illinois.edu)

Dataset Overview
--------------
This dataset contains sentences extracted from reviews on a given topic. 
Example topics are “performance of Toyota Camry” and “sound quality of ipod nano”, etc.
There are 51 such topics in this dataset and the opinions are obtained from Tripadvisor(hotels), Edmunds.com(cars) and Amazon.com(various electronics).

There are approximately 100 sentences per topic. 

This dataset was used for the following paper:
Kavita Ganesan, Cheng Xiang Zhai, and Jiawei Han, "Opinosis: A Graph Based Approach to Abstractive Summarization of Highly Redundant Opinions", Proceedings of the 23rd International Conference on Computational Linguistics (COLING 2010), Beijing, China, 2010.

The Opinosis dataset also comes with human composed summaries 
used for the above paper. I have  also provided some scripts to help with the summarization/evaluation tasks using ROUGE. 

For any questions, contact kganes2@illinois.edu .
