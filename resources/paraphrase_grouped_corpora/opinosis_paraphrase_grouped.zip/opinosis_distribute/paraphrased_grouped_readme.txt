
This corpus was prepared by Lyndon White (lyndon.white@research.uwa.edu.au).
It is derived from another corpus (readme for that corpus should have been distributed with this file.)

This corpus is annotated with paraphrase groups.

The corpus is contained in the file `phrases.txt`
This has one sentence per line.

`phrase_groups.csv` is the annotations.
It contains two columns: 
phrase_index and paraphrase_group_index.
the phrase_index is corresponds to the line in the `phrases.txt` file, starting from 0 being the first line.

The paraphrase_group_index identifies which group of paraphrases the sentence given by the phrase_index belongs to.

So were the `phrase_groups.csv` to read:

    phrase_index,paraphrase_group_index
    0,0
    1,0
    2,0
    3,1
    4,1
    5,1

That says that the sentences on lines 0,1,and 2 have the same meaning,
and that the sentences on 3,4 and 5 have the same meaning (but a different meaning to sentences 0,1, and 2).


It would be appreciated if the use of this corpus was indicated with a appropriate citation, the the paper it was created for, and to the paper describing the orignal corpus from which this is derived.
