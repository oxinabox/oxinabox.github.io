Includes here is the code for the paper.
It is released under CRAPL (http://matt.might.net/articles/crapl/), with all that entails.
It was deloped in IJulia within JuPyTer (http://jupyter.org/), and this is the best way to view it -- see the code_jupyter folder.

For those wishing a quick look to understand how it was, who do not have an IJulia environment set up,
the exact same code is in code_flattened, but without the JuPyTer cell structure.

I doubt running any of them end to end will not simply crash,
the cells have to run in a particular order, and some cells have been editted several times during testing.
For this reason, I have concluded that JuPyTer does not lead to reproduce-able (the temptation to edit cells is too great), and will not be using it for the core of my future works.

The results folder contains the results reported in the paper. 
And several more not reported.
Much rawer results, that the tables in the paper summarise.

